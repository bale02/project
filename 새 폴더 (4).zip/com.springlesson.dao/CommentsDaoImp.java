package com.springlesson.dao;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.springlesson.vo.Comments;

@Repository
public class CommentsDaoImp implements CommentsDao{
	
	@Inject
	SqlSession sqlSession;
	
	private final static String CommentsMapper = "com.springlesson.mappers.CommentsMappers";
	
	
}//class end