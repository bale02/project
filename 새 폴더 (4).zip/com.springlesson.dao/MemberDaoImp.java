package com.springlesson.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.springlesson.vo.LoginVo;
import com.springlesson.vo.Member;
import com.springlesson.vo.Paging;

@Repository
public class MemberDaoImp implements MemberDao{
	
	private static final Logger logger = LoggerFactory.getLogger(MemberDaoImp.class);
	
	@Inject
	SqlSession sqlSession;
	
	private final static String MemberMapper = "com.springlesson.mappers.MemberMappers";

	
	
}//class end
