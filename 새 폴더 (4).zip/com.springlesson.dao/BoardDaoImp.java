package com.springlesson.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.springlesson.vo.Board;
import com.springlesson.vo.Likes;
import com.springlesson.vo.Paging;

@Repository
public class BoardDaoImp implements BoardDao{
	
	@Inject
	SqlSession sqlSession;
	
	private final static String BoardMapper = "com.springlesson.mappers.BoardMappers";
	
	
}//class end
