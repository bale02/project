package com.springlesson.dao;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.springlesson.vo.MemberAlbum;

@Repository
public class MemberAlbumDaoImp implements MemberAlbumDao{
	
	@Inject
	SqlSession sqlSession;
	
	private final static String MemberAlbumMapper = "com.springlesson.mappers.MemberAlbumMappers";
	
	
}//class end
