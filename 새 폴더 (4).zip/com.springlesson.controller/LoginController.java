package com.springlesson.controller;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.inject.Inject;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.springlesson.service.MemberService;
import com.springlesson.util.ImgFileUploadUtil;
import com.springlesson.vo.CheckIdVo;
import com.springlesson.vo.LoginVo;
import com.springlesson.vo.Member;
import com.springlesson.vo.MemberAlbum;

@Controller
public class LoginController {
	
	@Inject
	private MemberService service;
	
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@RequestMapping(value="/login.do", method=RequestMethod.GET)
	public String loginForm(){
		return "login/LoginForm";
	}//end
	
	@RequestMapping(value="/login.do", method=RequestMethod.POST)
	public String login(Member mem, HttpSession session, RedirectAttributes rttr
			, HttpServletResponse res, @CookieValue(value="idCookie",required=false) String idCookieVal) throws Exception{
		
	   return null;
	}
	
	
	
}//class End

