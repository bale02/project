package com.springlesson.controller;

import java.io.File;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.springlesson.service.BoardService;
import com.springlesson.util.ImgFileUploadUtil;
import com.springlesson.vo.Board;
import com.springlesson.vo.Likes;
import com.springlesson.vo.LoginVo;
import com.springlesson.vo.Paging;

@Controller
@RequestMapping("/board/*")
public class BoardController {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@Inject
	private BoardService service;
	
	@RequestMapping("boardList.do")
	public String list(Model model,Paging paging) throws Exception{
		
		return "board/BoardList";
	}
	

	
}//class END
